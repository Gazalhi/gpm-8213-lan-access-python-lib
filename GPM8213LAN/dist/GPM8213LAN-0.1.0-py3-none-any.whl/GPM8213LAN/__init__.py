# -*- coding: utf-8 -*-
"""
GPM-8213-LAN access and smart measurment

@author: Hugo_MILAN
email : hugo.milan@ens-paris-saclay.fr
"""
__author__ = "Hugo MILAN"
__license__ = "GPL"
__version__ = "1.0.0"
__maintainer__ = "Hugo MILAN"
__email__ = "hugo.milan@ens-paris-saclay.fr"
__status__ = "Education"
